import React from "react";

function Footer() {
  return (
    <footer className="footer">
        <p>&copy; Copyright
            <script>document.write(new Date().getFullYear());</script> By OJAM
        </p>
    </footer>
  );
}

export default Footer;
